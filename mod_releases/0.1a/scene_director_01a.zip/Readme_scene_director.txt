Scene Director is a mod for GTA V specifically aimed at Director Mode and Rockstar Editor. It will allow you to set up a movie shot by yourself and should hopefully contribute to some new awesome movies. 

It's currently in a very unpolished alpha stage.

It's intended to play together with other trainers. For example once you've clone or possessed a pedestrian, you could change the skin of the model using any trainer (I prefer Enhanced Trainer as it allows me to store skins and vehicles I want to use in a video). Another is example is that you might use a trainer which allows you to start animations or scenarios (like smoking etc). This animation will continue to play as you swap away from the model, but when you switch back the animation will be stopped so you can take control of the character.

The controls are as follows:

F9 Possess nearest pedestrian
Free aim + F9 Possess targeted pedestrian

F10 Clone current player
If current player is in a vehicle, clones will become passengers

ALT+0 Possess previous pedestrian or clone

CTRL + 1-9 Assign current player to slot 1-9
ALT + 1-9 Swap to player in slot 1-9

Blips with number in the map will indicate the location of the pedestraian in slot 1-9.

If the player being swapped from is the driver of a vehicle and has a waypoint, the player will continue to drive towards the waypoint.

ALT + T Teleport the player to waypoint

CTRL + F Enter nearest vehicle as a passenger
If the player passenger has a waypoint, the vehicle will proceed to this waypoint. 
If the player passenger changes the waypoint while he's in the car, the vehicle will proceed to the new waypoint

Note: 
- that the vehicle currently won't stop at the waypoint, but will continue to circle the location 
- if you try to do enter as passenger when the driver's door is closest, the player will throw out the driver and then proceed to the passenger seat
